<?php

// create a connection with the database
$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = 'Mantazs@2006';
$dbName = 'GeorgianIlacStudents';

$conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

if($conn -> connect_error){
    die("Connection failed.".$conn -> connect_error);
}
if($_SERVER["REQUEST_METHOD"] == "POST"){
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO Students(username, password) VALUES('$username','$password')";

    if($conn -> query($sql) === TRUE){
        echo "Registration Successful!";
        sleep(5);
        header("Location: index.html");
    }
}
?>