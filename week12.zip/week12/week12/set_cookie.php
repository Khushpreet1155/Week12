<?php

if($_SERVER["REQUEST_METHOD"]=="POST"){
    $username = $_POST["username"];
    // set a cookie for username:
    // setcookie(cookie name, variable it will contain, time(in sec), available for one page or all pages("/"))
    setcookie("username", $username, time()+60, "/");
}

?>